﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
    public class Sql : IArchivo<Queue<Patente>>
    {
        SqlConnection conexion;
        SqlCommand comando;

        public Sql()
        {
            this.conexion = new SqlConnection(Properties.Settings.Default.cadena);

            this.comando = new SqlCommand();
            this.comando.CommandType = System.Data.CommandType.Text;
            this.comando.Connection = this.conexion;
        }

        public void Guardar(string tabla, Queue<Patente> datos)
        {
            conexion.Open();
            try
            {
                foreach (Patente auxPatente in datos)
                {
                    comando.CommandText = "INSERT INTO Patentes (patente,tipo) VALUES ('" + auxPatente.CodigoPatente + "','" + auxPatente.TipoCodigo + "')";
                    comando.ExecuteNonQuery();
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void Leer(string tabla, out Queue<Patente> datos)
        {
            SqlDataReader lector;
            datos = new Queue<Patente>();
            conexion.Open();
            comando.CommandText = "SELECT * FROM " + tabla;

            try
            {
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    Patente auxPatente = new Patente(lector["patente"].ToString(), (Patente.Tipo)lector["tipo"]);
                    datos.Enqueue(auxPatente);
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Close();
            }

        }
    }
}
