﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades;

namespace Archivos
{
    public class Texto : IArchivo<Queue<Patente>>
    {
        public void Guardar(string archivo, Queue<Patente> datos)
        {
            StreamWriter auxArchivo = null;

            try
            {
                auxArchivo = new StreamWriter(archivo);
                if (!(auxArchivo is null || datos is null))
                {
                    foreach (Patente auxPatente in datos)
                    {
                        auxArchivo.WriteLine(auxPatente.ToString());
                    }

                }
                else
                {
                    throw (new Exception());
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (auxArchivo != null)
                    auxArchivo.Close();
            }

        }

        public void Leer(string archivo, out Queue<Patente> datos)
        {
            StreamReader lector;
            datos = new Queue<Patente>();

            if (File.Exists(archivo))
            {
                lector = new StreamReader(archivo);

                while (!lector.EndOfStream)
                {
                    string patenteString = lector.ReadLine().Trim();
                    Patente patente = new Patente(patenteString, Patente.Tipo.Mercosur);
                    datos.Enqueue(patente);
                }

                lector.Close();
            }

        }



    }
}
