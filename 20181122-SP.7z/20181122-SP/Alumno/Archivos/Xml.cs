﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        public void Guardar(string archivo, T datos)
        {
            StreamWriter streamWriter = null;
            try
            {
                streamWriter = new StreamWriter(archivo);
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                xmlSerializer.Serialize(streamWriter, datos);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (streamWriter != null)
                    streamWriter.Close();
            }
        }

        public void Leer(string archivo, out T datos)
        {
            XmlSerializer xmlSerializer;
            XmlTextReader lecturaArchivo;

            if (File.Exists(archivo))
            {
                xmlSerializer = new XmlSerializer(typeof(T));
                lecturaArchivo = new XmlTextReader(archivo);
                datos = (T)xmlSerializer.Deserialize(lecturaArchivo);
                lecturaArchivo.Close();
            }
            else
            {
                datos = default(T);
            }
        }


    }
}
