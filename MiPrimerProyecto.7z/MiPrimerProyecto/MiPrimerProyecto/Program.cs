﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiPrimerProyecto
{
    class Program
    {
        static int miEntero;
        static double miDouble;
        static string miPalabra;
        static bool miBooleana;
        String miPal;
        static void Main(string[] args)
        {
            miEntero = 5;
            miPalabra = miBooleana.ToString();
            System.Console.WriteLine(miPalabra);  // Input
            ConsoleKeyInfo cki = Console.ReadKey();  // Espera un Enter
            Console.WriteLine(cki.Key);
        }
    }
}
